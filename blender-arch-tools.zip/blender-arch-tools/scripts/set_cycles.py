import bpy
scene=bpy.context.scene
scene.render.engine='CYCLES'
scene.cycles.samples=512
scene.cycles.use_denoising=True
print("Cycles configured.")
