import bpy

for i, obj in enumerate(bpy.context.selected_objects, start=1):
    obj.name = f"Building_{i}"
print("Objects renamed.")
