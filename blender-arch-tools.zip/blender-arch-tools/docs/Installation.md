# Installation

1. Open Blender.
2. Open the Scripting workspace.
3. Load a script.
4. Click Run Script.
