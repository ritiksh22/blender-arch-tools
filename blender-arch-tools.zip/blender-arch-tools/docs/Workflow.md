# SketchUp to Blender Workflow

1. Export FBX from SketchUp.
2. Import into Blender.
3. Apply scale.
4. Assign materials.
5. Render with Cycles.
