# Blender Architecture Tools

A collection of open-source Blender scripts and workflow guides for architectural visualization.

## Features
- Apply scale automatically
- Batch rename objects
- Scene cleanup
- Camera setup
- Cycles render presets

## Installation
1. Download this repository.
2. Open Blender.
3. Go to the Scripting workspace.
4. Open a script from the scripts folder.
5. Click Run Script.

## Contributing
Contributions are welcome.
